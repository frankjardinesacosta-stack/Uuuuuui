# Panther iOS — Cloudflare Workers + D1 (prueba)

1. Crea una cuenta en https://dash.cloudflare.com/ y configura Wrangler en tu equipo con `npm install -g wrangler` y `wrangler login`.
2. En la carpeta `cloudflare`, ejecuta `wrangler d1 create panther-ios-test`.
3. Copia el `database_id` devuelto a `wrangler.toml` en lugar de `REEMPLAZAR_ID_D1`.
4. Ejecuta `wrangler d1 execute panther-ios-test --remote --file=schema.sql`.
5. Ejecuta `wrangler secret put ADMIN_KEY` e introduce una contraseña nueva y fuerte (no publiques Naruto00 en internet).
6. Ejecuta `wrangler deploy`. Copia la dirección HTTPS `https://...workers.dev`.
7. Sustituye `https://TU-SERVIDOR-PANTHER.example.com` en `ThreeOneOSFive/App.swift` por la URL HTTPS de tu Worker; después compila la app iOS.

El panel web está en la raíz de la URL del Worker. Las keys se generan desde el panel; no se incluyen claves de prueba prepublicadas.
Las operaciones de generar 10,000 claves pueden superar los límites de CPU/consultas del plan gratuito: usa lotes pequeños (100 o menos).
Esta implementación es de prueba, no está desplegada ni verificada en un iPhone. Para producción, añade control de acceso más robusto, límites de intentos, auditoría y transacciones para actualización del catálogo.
D1 y Workers gratuitos tienen cuotas. La identificación por identifierForVendor no es un identificador físico permanente.


## Bot privado de Telegram (SENSI OG)

El Worker incluye un webhook en `/telegram/webhook`. Configura estos secretos en Cloudflare Workers → Settings → Variables and Secrets (tipo Secret):

- `BOT_TOKEN`: token nuevo del bot emitido por @BotFather. No lo pongas en el código, el ZIP ni la app.
- `TELEGRAM_ADMIN_ID`: `8833269908` (solo esta cuenta puede usar el bot).
- `TELEGRAM_WEBHOOK_SECRET`: una cadena aleatoria larga creada por ti.

Después de desplegar el Worker, registra el webhook con Telegram usando `https://api.telegram.org/bot<TU_TOKEN_NUEVO>/setWebhook` y los parámetros `url=https://TU-WORKER/telegram/webhook` y `secret_token=EL_MISMO_TELEGRAM_WEBHOOK_SECRET`. Hazlo desde un entorno privado; no compartas la URL que contiene el token.

En Telegram abre @External7_bot y envía `/start`. El menú permite generar 1, 5 o 10 KEYs de 30 días, listar las últimas 25 y revocar con `/revoke TU_KEY`. Cada KEY sigue vinculándose a un solo dispositivo, como en el servidor actual. La revocación se aplica cuando la app vuelve a validar la KEY con el servidor.
