# Bot privado SENSI OG

Administrador autorizado: `8833269908`

1. Revoca el token publicado anteriormente en @BotFather y genera uno nuevo.
2. Despliega `cloudflare/` como Cloudflare Worker.
3. En Settings → Variables and Secrets agrega como **Secrets**: `BOT_TOKEN`, `TELEGRAM_ADMIN_ID` con valor `8833269908`, y `TELEGRAM_WEBHOOK_SECRET` con un valor aleatorio largo.
4. Registra el webhook de Telegram apuntando a `https://TU-WORKER/telegram/webhook`, incluyendo el header/parametro `secret_token` con el mismo valor de `TELEGRAM_WEBHOOK_SECRET`. La llamada a `setWebhook` debe hacerse en privado porque la URL de la API contiene el token.
5. Abre `@External7_bot` y envía `/start`.

Comandos: `/menu`, `/help`, `/revoke TU_KEY`. El menú genera lotes de 1/5/10 KEYs de 30 días y lista las últimas 25. Cada KEY permite un dispositivo. La revocación elimina la KEY del servidor y será efectiva en el próximo chequeo de la app.

**Importante:** el token del bot nunca debe incluirse en la IPA, el repositorio, este ZIP ni el código fuente.
